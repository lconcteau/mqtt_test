
0.4 (2019-07-29)
----------------

Use the new Erlang MQTT v5.0 client

0.3 (2016-01-29)
----------------

emqtt_bench_sub: support to subscribe mutiple topics (#9)

0.2 (2015-10-08)
----------------

emqtt_bench_pub, emqtt_bench_sub scripts

0.1 (2015-04-23)
----------------

first public release

