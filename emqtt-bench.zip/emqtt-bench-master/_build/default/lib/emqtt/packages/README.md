emqx-packages
=============

EMQ X RPM/Debian Packages

NOTICE: Requires Erlang/OTP R21+ to build since 3.0 release.

How to use
----------------------------

```
cd project-root-directory-path
EMQX_DEPS_DEFAULT_VSN=${version} make emqx-pkg
```

License
-------

Apache License Version 2.0

Author
------

EMQ X Team.
