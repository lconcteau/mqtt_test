-module(fake_transport).
-export([send/2]).

send(_, _) -> ok.
